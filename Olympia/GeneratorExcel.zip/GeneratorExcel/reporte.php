<?php
    require 'vendor/autoload.php';
    require 'conexion.php';

    use PhpOffice\PhpSpreadsheet\Spreadsheet;
    use PhpOffice\PhpSpreadsheet\IOFactory;

    $sql1 = "SELECT Curp,Nombre,Ape_paterno,Ape_materno,Padecimientos FROM info_personal";
    $sql2 = "SELECT Correo, Direccion, Telefono,Contacto_Emerge FROM info_contacto";
    $sql3 = "SELECT universidad, carrera, promedio,creditos FROM info_escuela";
    $sql4 = "SELECT Estatus,Modalidad FROM servicio";
    $sql5 = "SELECT Modalidad, fecha_inicio, fecha_fin,horario FROM datos";

    $excel = new Spreadsheet();

    $resultado1 = $mysqli-> query($sql1);
    $resultado2 = $mysqli-> query($sql2);
    $resultado3 = $mysqli-> query($sql3);


    $hojaActiva = $excel -> getActiveSheet();
    $hojaActiva -> setTitle("Datos");

    $hojaActiva -> getColumnDimension('A')-> setWidth(10);
    $hojaActiva -> setCellValue('A1','CURP');
    $hojaActiva -> getColumnDimension('B')-> setWidth(30);
    $hojaActiva -> setCellValue('B1','NOMBRE');
    $hojaActiva -> getColumnDimension('C')-> setWidth(30);
    $hojaActiva -> setCellValue('C1','APELLIDO PATERNO');
    $hojaActiva -> getColumnDimension('D')-> setWidth(30);
    $hojaActiva -> setCellValue('D1','APELLIDO MATERNO');
    $hojaActiva -> getColumnDimension('E')-> setWidth(30);
    $hojaActiva -> setCellValue('E1','PADECIMIENTOS');

    $hojaActiva -> getColumnDimension('F')-> setWidth(10);
    $hojaActiva -> setCellValue('F1','CORREO');
    $hojaActiva -> getColumnDimension('G')-> setWidth(10);
    $hojaActiva -> setCellValue('G1','DIRECCION');
    $hojaActiva -> getColumnDimension('H')-> setWidth(10);
    $hojaActiva -> setCellValue('H1','TELEFONO');
    $hojaActiva -> getColumnDimension('I')-> setWidth(10);
    $hojaActiva -> setCellValue('I1','CONTACTO_EMERGENCIA');

    $hojaActiva -> getColumnDimension('J')-> setWidth(10);
    $hojaActiva -> setCellValue('J1','UNIVERSIDAD');
    $hojaActiva -> getColumnDimension('K')-> setWidth(10);
    $hojaActiva -> setCellValue('K1','CARRERA');
    $hojaActiva -> getColumnDimension('L')-> setWidth(10);
    $hojaActiva -> setCellValue('L1','PROMEDIO');
    $hojaActiva -> getColumnDimension('M')-> setWidth(10);
    $hojaActiva -> setCellValue('M1','CREDITOS');

    $hojaActiva -> getColumnDimension('N')-> setWidth(10);
    $hojaActiva -> setCellValue('N1','ESTATUS');
    $hojaActiva -> getColumnDimension('O')-> setWidth(10);
    $hojaActiva -> setCellValue('O1','MODALIDAD');
    
    $hojaActiva -> getColumnDimension('P')-> setWidth(10);
    $hojaActiva -> setCellValue('P1','FECHA_INICIO');
    $hojaActiva -> getColumnDimension('Q')-> setWidth(10);
    $hojaActiva -> setCellValue('Q1','FECHA_FIN');
    $hojaActiva -> getColumnDimension('R')-> setWidth(10);
    $hojaActiva -> setCellValue('R1','HORARIO');
    
    $fila =2;

    while($rows= $resultado1-> fetch_assoc())
    {
        $hojaActiva -> setCellValue('A'.$fila, $rows['Curp']);
        $hojaActiva -> setCellValue('B'.$fila, $rows['Nombre']);
        $hojaActiva -> setCellValue('C'.$fila, $rows['Ape_paterno']);
        $hojaActiva -> setCellValue('D'.$fila, $rows['Ape_materno']);
        $hojaActiva -> setCellValue('E'.$fila, $rows['Padecimientos']);

        $fila++;
    }

    $fila =2;
    while($rows= $resultado2-> fetch_assoc())
    {
        $hojaActiva -> setCellValue('F'.$fila, $rows['Correo']);
        $hojaActiva -> setCellValue('G'.$fila, $rows['Direccion']);
        $hojaActiva -> setCellValue('H'.$fila, $rows['Telefono']);
        $hojaActiva -> setCellValue('I'.$fila, $rows['Contacto_Emerge']);
        $fila++;
    }

    $fila =2;
    while($rows= $resultado3-> fetch_assoc())
    {
        $hojaActiva -> setCellValue('J'.$fila, $rows['universidad']);
        $hojaActiva -> setCellValue('K'.$fila, $rows['carrera']);
        $hojaActiva -> setCellValue('L'.$fila, $rows['promedio']);
        $hojaActiva -> setCellValue('M'.$fila, $rows['creditos']);
        $fila++;
    }

    $fila =2;
    while($rows= $resultado3-> fetch_assoc())
    {
        $hojaActiva -> setCellValue('N'.$fila, $rows['Estatus']);
        $hojaActiva -> setCellValue('O'.$fila, $rows['Modalidad']);
        $fila++;
    }

    $fila =2;
    while($rows= $resultado3-> fetch_assoc())
    {
        $hojaActiva -> setCellValue('P'.$fila, $rows['fecha_inicio']);
        $hojaActiva -> setCellValue('Q'.$fila, $rows['fecha_fin']);
        $hojaActiva -> setCellValue('R'.$fila, $rows['horario']);
        $fila++;
    }

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="datos.xlsx"');
    header('Cache-Control: max-age=0');

    $writer = IOFactory::createWriter($excel, 'Xlsx');
    $writer->save('php://output');
    exit;
 